from pathlib import Path
import re,xml.etree.ElementTree as ET
from lupa.lua51 import LuaRuntime
root=Path('build/Hekili')
lua=LuaRuntime(unpack_returned_tuples=True)
lua.execute('''
_NOW=100
bit={}
local function bitop(a,b,op)
 a=a%4294967296;b=b%4294967296;local r,p=0,1
 for i=1,32 do local x,y=a%2,b%2;if op(x,y) then r=r+p end;a=math.floor(a/2);b=math.floor(b/2);p=p*2 end
 return r>=2147483648 and r-4294967296 or r
end
function bit.band(a,b,...) local r=bitop(a,b,function(x,y) return x==1 and y==1 end);if select('#',...)>0 then return bit.band(r,...) end return r end
function bit.bor(a,b,...) local r=bitop(a,b,function(x,y) return x==1 or y==1 end);if select('#',...)>0 then return bit.bor(r,...) end return r end
function bit.bxor(a,b,...) local r=bitop(a,b,function(x,y) return x~=y end);if select('#',...)>0 then return bit.bxor(r,...) end return r end
function bit.bnot(a) return -1-a end
function bit.lshift(a,n) return (a*2^n)%4294967296 end
function bit.rshift(a,n) return math.floor((a%4294967296)/2^n) end

function wipe(t) for k in pairs(t) do t[k]=nil end return t end
table.wipe=wipe;tinsert=table.insert;tremove=table.remove
strmatch=string.match;strfind=string.find;strsub=string.sub;strlower=string.lower;strupper=string.upper
format=string.format;max=math.max;min=math.min;abs=math.abs;floor=math.floor;ceil=math.ceil
function strsplit(delim,s) local t={} for v in string.gmatch(s,'[^'..delim..']+') do t[#t+1]=v end return unpack(t) end
function strtrim(s) return s:match('^%s*(.-)%s*$') end
INVSLOT_HEAD=1;INVSLOT_WAIST=6;INVSLOT_FEET=8;INVSLOT_HAND=10;INVSLOT_BACK=15;INVSLOT_MAINHAND=16;INVSLOT_OFFHAND=17;INVSLOT_RANGED=18
string.trim=strtrim;string.split=function(s,d) return strsplit(d,s) end
BOOKTYPE_SPELL='spell';CR_HASTE_SPELL=20;INVSLOT_LAST_EQUIPPED=19;INVSLOT_TRINKET1=13;INVSLOT_TRINKET2=14
COMBATLOG_OBJECT_REACTION_FRIENDLY=16
RAID_CLASS_COLORS={PALADIN={r=1,g=.5,b=.7}}
LOCALIZED_CLASS_NAMES_MALE={};LOCALIZED_CLASS_NAMES_FEMALE={}
for _,c in ipairs({'WARRIOR','PALADIN','HUNTER','ROGUE','PRIEST','DEATHKNIGHT','SHAMAN','MAGE','WARLOCK','DRUID'}) do LOCALIZED_CLASS_NAMES_MALE[c]=c;LOCALIZED_CLASS_NAMES_FEMALE[c]=c end
SlashCmdList={};_FRAMES={}
local fm={}
function fm:SetScript(k,v) self.scripts[k]=v end
function fm:GetScript(k) return self.scripts[k] end
function fm:HookScript(k,v) local old=self.scripts[k];self.scripts[k]=function(...) if old then old(...) end v(...) end end
function fm:RegisterEvent(e) self.registered[e]=true end
function fm:UnregisterAllEvents() self.registered={} end
function fm:UnregisterEvent(e) self.registered[e]=nil end
function fm:GetName() return self.name end
function fm:GetParent() return self.parent end
function fm:GetFrameStrata() return 'MEDIUM' end
function fm:GetFrameLevel() return 1 end
function fm:GetSize() return self:GetWidth(),self:GetHeight() end
function fm:GetWidth() return 300 end
function fm:GetHeight() return 200 end
function fm:GetScale() return 1 end
function fm:GetEffectiveScale() return 1 end
function fm:IsShown() return self.shown~=false end
fm.IsVisible=fm.IsShown
function fm:Show() self.shown=true end
function fm:Hide() self.shown=false end
function fm:GetText() return self.text or '' end
function fm:SetText(t) self.text=t end
function fm:GetVertexColor() return 1,1,1,1 end
function fm:GetFont() return 'font',12,'' end
function fm:NumLines() return 0 end
function fm:GetStringWidth() return 20 end
function fm:GetNormalTexture() return self:CreateTexture() end
fm.GetPushedTexture=fm.GetNormalTexture;fm.GetHighlightTexture=fm.GetNormalTexture
function fm:GetObjectType() return self.kind end
function fm:IsObjectType(k) return self.kind==k end
function fm:CreateTexture() return CreateFrame('Texture',nil,self) end
function fm:CreateFontString() return CreateFrame('FontString',nil,self) end
function fm:CreateAnimationGroup() return CreateFrame('AnimationGroup') end
function fm:CreateAnimation() return CreateFrame('Animation') end
setmetatable(fm,{__index=function(t,k)
 if k:match('^Set') or k:match('^Enable') or k:match('^RegisterFor') or k=='ClearAllPoints' or k=='Stop' then return function() end end
end})
function CreateFrame(kind,name,parent,template)
 assert(template~='BackdropTemplate','modern template reached legacy CreateFrame')
 local f=setmetatable({name=name,parent=parent,kind=kind,scripts={},events={},registered={},shown=true},{__index=fm})
 _FRAMES[#_FRAMES+1]=f;if name then _G[name]=f end return f
end
UIParent=CreateFrame('Frame','UIParent');WorldFrame=CreateFrame('Frame','WorldFrame')
GameTooltip=CreateFrame('GameTooltip','GameTooltip');ChatFontNormal=CreateFrame('Font','ChatFontNormal')
function GetTime() return _NOW end
function GetBuildInfo() return '3.3.5','12340','Jun 2010',30300 end
function GetAddOnMetadata(addon,key) return key=='X-Flavor' and 'Wrath' or '3.3.5a-prot-alpha.1' end
function GetAddOnInfo() return 'Hekili','Hekili','',true end
function IsAddOnLoaded() return false end
function GetRealmName() return 'Icecrown' end
function UnitClass() return 'Paladin','PALADIN' end
function UnitName() return 'TestPaladin' end
function UnitGUID(unit) return unit=='player' and '0x0000000000000001' or '0xF1300079A3000001' end
function UnitSex() return 2 end
function UnitLevel() return 80 end
function UnitRace() return 'Human','Human' end
function UnitFactionGroup() return 'Alliance' end
_SPELLS={ [53595]={'Hammer of the Righteous','',0,0,0,5},[48952]={'Holy Shield','Rank 6',100,0,0,0},[48951]={'Holy Shield','Rank 5',100,0,0,0},[25956]={'Improved Judgements','Rank 1',0,0,0,0},[25957]={'Improved Judgements','Rank 2',0,0,0,0} }
_BOOK={48952,53595};_TALENT_RANK=1
function GetSpellInfo(spell,book)
 if book then spell=_BOOK[spell] end
 if type(spell)=='string' then for id,s in pairs(_SPELLS) do if s[1]==spell then spell=id break end end end
 if type(spell)=='string' then spell=tonumber(spell:match('^Spell(%d+)$')) or spell end
 local s=_SPELLS[spell];if not s and type(spell)=='number' and spell<=80000 then s={'Spell'..spell,'',0,0,0,30} end;if not s then return end
 return s[1],s[2],'icon',s[3],false,0,s[4],s[5],s[6]
end
function GetSpellName(index) return GetSpellInfo(_BOOK[index]) end
function GetSpellLink(index) return '|Hspell:'.._BOOK[index]..'|h' end
function GetNumSpellTabs() return 1 end
function GetSpellTabInfo() return 'Protection','icon',0,#_BOOK end
function GetNumTalentTabs() return 3 end
function GetNumTalents(tab) return tab==3 and 1 or 0 end
function GetTalentInfo() return 'Improved Judgements','icon',1,1,_TALENT_RANK,2 end
function GetTalentTabInfo(tab) return 'tree','icon',tab==2 and 51 or 10 end
function IsSpellKnown(id) for _,v in ipairs(_BOOK) do if v==id then return true end end return false end
function GetActiveTalentGroup() return 1 end
function UnitBuff(unit,index) if index==1 then return 'Holy Shield','Rank 6','icon',8,nil,10,110,'player',false,48952 end end
function UnitDebuff(unit,index) if index==1 then return 'Forbearance','','icon',0,nil,120,220,'player',false,25771 end end
function UnitCastingInfo() return 'Holy Shield','Rank 6','Holy Shield','icon',100000,101500,false,4,false end
function UnitChannelInfo() return 'Holy Shield','Rank 6','Holy Shield','icon',100000,101500,false,false end
function GetSpellCooldown() return 0,0,1 end
function GetItemCooldown() return 0,0,1 end
function GetCombatRatingBonus() return 0 end
function GetNumRaidMembers() return 0 end
function GetNumPartyMembers() return 0 end
function GetPlayerSpeed() return 0 end
function GetManaRegen() return 10,5 end
function UnitAttackSpeed() return 2.6 end
function UnitPowerType() return 0 end
function UnitPower() return 5000 end
function UnitPowerMax() return 5000 end
function UnitHealth() return 30000 end
function UnitHealthMax() return 30000 end
function GetFramerate() return 60 end
function GetScreenWidth() return 1920 end
function GetScreenHeight() return 1080 end
function GetCVar(k) return ({gxResolution='1920x1080',gxWindowedResolution='1920x1080',gxMonitor='0',nameplateShowEnemies='1'})[k] or '0' end
function GetCVarBool() return false end
function IsLoggedIn() return false end
function debugprofilestop() return 0 end
function debugstack() return '' end
function geterrorhandler() return function(e) error(e) end end
function hooksecurefunc() end
function GetLocale() return 'enUS' end
function date(...) return os.date(...) end
function time() return os.time() end
function InCombatLockdown() return false end
function GetMouseFocus() return UIParent end
function RegisterAddonMessagePrefix() return true end
function IsInInstance() return false,'none' end
function InterfaceOptions_AddCategory() end
Minimap=CreateFrame('Frame','Minimap');MinimapCluster=Minimap
function GetInventorySlotInfo() return 18 end
function GetInventoryItemID() end
function GetItemInfo() end
function GetItemCount() return 0 end
function GetItemSpell() end
function GetSpellCount() return 0 end
function UnitExists(unit) return unit=='player' or unit=='target' end
function UnitCanAttack() return true end
function UnitIsUnit(a,b) return a==b end
function UnitIsDead() return false end
function UnitIsDeadOrGhost() return false end
function UnitAffectingCombat() return false end
function UnitThreatSituation() return 3 end
function IsUsableSpell() return true,false end
function IsSpellInRange() return 1 end
function GetActionInfo() end
function SetOverrideBindingClick() end
function ClearOverrideBindings() end
function GetBindingKey() end
function GetShapeshiftForm() return 0 end
function GetGlyphSocketInfo() end
function GetNetStats() return 0,0,50,50 end
function GetInventoryItemLink() end
function GetInventoryItemCooldown() return 0,0,1 end
function GetInventoryItemTexture() end
function IsMounted() return false end
function IsResting() return false end
function IsFlying() return false end
function UnitHasVehicleUI() return false end
function HasVehicleActionBar() return false end
function UnitOnTaxi() return false end
function GetTotemInfo() return false,nil,0,0,nil end
function UnitStat() return 100,100 end
MANA_PER_INTELLECT=15
function UnitClassification() return 'normal' end
function UnitCreatureType() return 'Undead' end
function UnitIsPVP() return false end
function UnitIsFriend() return false end
function UnitIsPlayer() return false end
function GetNumShapeshiftForms() return 0 end
function GetInstanceInfo() return 'Icecrown','none',1,'Normal',5 end
''')
# Original Blizzard constants, loaded from a historical FrameXML mirror.
g=Path('client-api/GlobalStrings.lua')
if g.exists(): lua.execute(g.read_text())
runner=lua.eval('function(s,n,ns) local f,e=loadstring(s,n);assert(f,e); return f("Hekili",ns) end')
ns=lua.table()
loaded=[]
def load(path):
    path=path.resolve()
    assert path.exists(),f'Missing addon dependency: {path}'
    if path.suffix.lower()=='.xml':
        tree=ET.parse(path)
        for elem in tree.getroot().iter():
            tag=elem.tag.split('}')[-1]
            if tag in ('Script','Include') and 'file' in elem.attrib:
                file=elem.attrib['file'].replace('\\','/')
                load(path.parent/file)
    elif path.suffix.lower()=='.lua':
        runner(path.read_text(),str(path),ns);loaded.append(path)

load(root/'Compat335.lua')
lua.execute('''
local C=Hekili335Compat
local a={C.GetSpellInfo(48952)}
assert(a[4]==0 and a[6]==0 and a[7]==48952,'spell-info conversion')
assert(select(7,C.GetSpellInfo('Holy Shield'))==48952,'spell-name rank resolution')
local b={C.UnitBuff('player',1)}
assert(b[2]=='icon' and b[3]==8 and b[6]==110 and b[10]==48952 and b[15]==1,'aura conversion')
assert(select(3,UnitBuff('player',1))=='icon','global legacy API was altered')
assert(select(4,C.UnitCastingInfo('player'))==100000,'cast conversion')
assert(IsPlayerSpell(25956) and not IsPlayerSpell(25957),'passive talent ranks')
local cleu={C.NormalizeEvent('COMBAT_LOG_EVENT_UNFILTERED',100,'SPELL_CAST_SUCCESS','src','name',16,'dst','target',64,53595,'Hammer',2)}
assert(cleu[3]==false and cleu[4]=='src' and cleu[8]=='dst' and cleu[12]==53595,'combat log conversion')
assert(select(12,CombatLogGetCurrentEventInfo())==53595,'combat log cache')
local u,c,id=C.NormalizeEvent('UNIT_SPELLCAST_SUCCEEDED','player','Holy Shield','Rank 6',4)
assert(u=='player' and c==4 and id==48952,'cast event conversion')
local u,target,c,id=C.NormalizeEvent('UNIT_SPELLCAST_SENT','player','Holy Shield','Rank 6','target')
assert(target=='target' and id==48952,'cast sent conversion')
assert(C.NPCID('0xF1300079A3000001')==31139,'legacy GUID creature ID')
local hits=0;local t=C_Timer.NewTimer(.2,function() hits=hits+1 end)
t:Cancel();_NOW=101
for _,f in ipairs(_FRAMES) do if f.scripts.OnUpdate then f.scripts.OnUpdate(f,1) end end
assert(hits==0,'timer cancellation')
C_Timer.After(.2,function() hits=hits+1 end);_NOW=102
for _,f in ipairs(_FRAMES) do if f.scripts.OnUpdate then f.scripts.OnUpdate(f,1) end end
assert(hits==1,'timer execution')
''')
print('PASS: legacy spell/aura/cast/talent/CLEU/GUID/timer adapters')
for path in root.rglob('*.lua'):
    lua.eval('function(s,n) local f,e=loadstring(s,n);assert(f,e) end')(path.read_text(),str(path))
print('PASS: Lua 5.1 syntax for every bundled Lua file')
for line in (root/'Hekili.toc').read_text().splitlines():
    if line.strip() and not line.startswith('#'):
        path=root/line.replace('\\','/')
        if path.name=='Compat335.lua': continue
        try: load(path)
        except Exception as e:
            print('LOAD FAILED:',path,'last loaded:',loaded[-1] if loaded else None);raise
print('PASS: complete addon load order:',len(loaded),'Lua chunks (mocked legacy client)')
lua.execute('Hekili:OnInitialize()')
print('PASS: addon OnInitialize (mocked legacy client)')
lua.execute('Hekili:SpecializationChanged();Hekili:BuildUI()')
print('PASS: specialization selection and display construction (mocked legacy client)')
lua.execute('Hekili:OnEnable()')
print('PASS: OnEnable (mocked legacy client)')
lua.execute('Hekili:RestoreDefaults();assert(Hekili.DB.profile.specs[2].package=="Protection 96");assert(#Hekili.DB.profile.packs["Protection 96"].lists.default==9)')
print('PASS: Protection pack is selected and restored with its complete action lists')
lua.execute('_BOOK={61411,53595,48952,48819,53408,20271,31801,25780,54428,48943,53601};Hekili335Compat.RefreshSpellbook();Hekili:SpecializationChanged();Hekili.PLAYER_ENTERING_WORLD=true;Hekili:LoadScripts();assert(Hekili:ScriptsLoaded());Hekili.DisplayPool.Primary.Active=true;Hekili.frameStartTime=0;Hekili.maxFrameTime=10;local co=coroutine.create(Hekili.Update);local n=0;repeat local ok,e=coroutine.resume(co);assert(ok,e);n=n+1;assert(n<200,"engine update did not complete") until coroutine.status(co)=="dead"')
lua.execute('assert(Hekili.DisplayPool.Primary.Recommendations[1].actionName=="seal_of_vengeance");assert(Hekili.DisplayPool.Primary.Recommendations[2].actionName=="sacred_shield");assert(Hekili.DisplayPool.Primary.Recommendations[3].actionName=="judgement_of_light")')
print('PASS: engine produces a three-action precombat prediction queue')
lua.execute('Hekili.State.combat=100;Hekili.State.aggro=true;local co=coroutine.create(Hekili.Update);repeat local ok,e=coroutine.resume(co);assert(ok,e) until coroutine.status(co)=="dead"')
print('PASS: combat recommendation engine update (mocked legacy client)')
if __name__=='__main__':
    Path('build/validation.txt').write_text('Legacy API adapter tests passed. All bundled Lua files parse in Lua 5.1. TOC/XML paths resolve. Addon load-order check passed under mocked original-client APIs. In-game validation remains required.\n')
